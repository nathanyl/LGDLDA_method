%clc;
%clear;
R=100;
% lncRNA similarity data
x=me8_300_30;
% Gene similarity data
y=ge8_300_30;
% Calculating associations between lncRNA and genes using low-dimensional
% spatial node representations with reconstruction matrix algorithm
[nncfqmg800,nnclambda800]=newstabselect_gsp(x,y,R);
%Gene similarity data
x_1=ge8_300_30;
% Disease similairy
y_1=phepn8_300_30;
% Calculating associations between genes and disease
[nncfqgp800,nncmu]=newstdlog_stdsl(x_1,y_1,R);

tpr800=zeros(1000,3);
fpr800=zeros(1000,3);


index=1;
% Setting different \Phi threshold
for thred=0.6:0.1:0.8
% Calculating low-dimensional expression (lncRNA and genes) 
nncedges_dg800=pred_networkyl(nncfqmg800,'threshold',thred);
% Calculating low-dimensional expression (genes and diseases) 
nncedges_gp800=pred_networkyl(nncfqgp800,'threshold',thred);
k_paths=2000; 
[wholepaths, kpath] =findkpath(nncedges_dg800, nncedges_gp800,k_paths);
%Calculating AUC
[nncTPR800,nncFPR800,nncAUC800]=cal_AUC(kpath);

tpr800(:,index)=nncTPR800;
fpr800(:,index)=nncFPR800;

index=index+1;
eval(['AUC800',num2str(thred*10),'=',num2str(nncAUC800),';']);

end

