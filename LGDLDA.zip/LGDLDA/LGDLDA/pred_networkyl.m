function edges=pred_networkyl(scores,varargin)

%Finally let us rank and stability select the edges 
% The method will be used twice. In terms of finding edges between DNA
% methylation and Gene expression, in terms of finding edges between Gene
% expression and Disease Trait
%
% Create list of predicted edges and optionally print them in a text file
% given a matrix of scores
%
% Syntax 1: edges=pred_networkyl(scores) will return the entire 
% list of edges with non-zero scores. 
%
% Syntax 2: edges=predict_network(scores,'option',optionvalue) 
% same with optional parameters chosen by user.
%
% REQUIRED INPUTS: 
% - scores: a ndm*nge matrix <coefficient matrix between DNA methylation and Gene>
% - (nge*ntrait matrix <coefficient matrix between Gene and Disease Trait>) of scores obtained running score_edges.
%
% OPTIONAL INPUTS:
% - threshold: threshold means edg existence probability in the predicted network (default=all possible)
% - genenames: cell array of strings containing names of genes -- required 
%              to write network in a file. No default value.
% - name_net: path/name.ext of the file to write the network -- required to
%             to write network in a file. No default value.
% Note that the function will return a warning if any of 'name_net' or
% 'genenames' is empty. 
% 
% Lin Yuan


%% Parse arguments
p = inputParser;   % Create an instance of the class.
p.addRequired('scores', @isfloat);
p.addParamValue('threshold', Inf, @isfloat);
p.addParamValue('genenames',{},@iscell);
p.addParamValue('name_net','',@ischar);
p.parse(scores,varargin{:});

%% Show which arguments were not specified in the call.
disp(' ') 
for k=1:numel(p.UsingDefaults)
   field = char(p.UsingDefaults(k));
   value = p.Results.(field);
   if isempty(value)   
       value = '[]';   
   end
   fprintf('   ''%s''    defaults to %s \n', field, value)
end


%% Initialization
% For Edges between DNA methylation and Gene expression
ndm=size(scores,1);
nge=size(scores,2);
edges = zeros(ndm*nge,3);
% For Edges between Gene expression and Disease trait
% nge=size(scores,1);
% ntrait=size(scores,2);
% edges = zeros(nge*ntrait,3);

%% Create list of edges
k=0;
for i=1:ndm  %nge
    for j=1:nge   %ntrait
            k=k+1;
            edges(k,:) =[i j scores(i,j)];
    end
end

%% Sort the edges
[a idx] = sort(edges(:,3),'descend');
edges = edges(idx,:);

%% Remove zero scores
% select edges existence probability large threshold
idx=edges(:,3)>p.Results.threshold;
% Sort slected edges
edges=edges(idx,:);
% Get number of selected edges
nedges=size(edges,1);



%% Write the network in a text file (optional)

if ~isempty(p.Results.genenames) && ~isempty(p.Results.name_net)
    genenames=p.Results.genenames;
    name_net=p.Results.name_net;
    fid = fopen(name_net,'w');
    for i=1:nedges
         fprintf(fid,'%s\t%s\t%f\r\n',genenames{edges(i,1)},genenames{edges(i,2)},edges(i,3));
    end
    fclose(fid);
end